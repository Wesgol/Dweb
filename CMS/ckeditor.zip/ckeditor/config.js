CKEDITOR.editorConfig = function( config ) {

        config.entities = false;
};